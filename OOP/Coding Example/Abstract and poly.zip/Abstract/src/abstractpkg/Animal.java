/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractpkg;

/**
 *
 * @author Owner
 */
 public  abstract class Animal {
  protected int legs;


  protected Animal(int legs) {
    this.legs = legs;
  }

  public void walk() {
    System.out.println("This animal walks on " + legs + " legs.\n");
  }

  public abstract void eat();




}
