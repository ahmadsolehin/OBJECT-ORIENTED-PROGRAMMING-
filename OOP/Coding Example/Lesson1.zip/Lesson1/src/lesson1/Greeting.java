
package lesson1;

/**
 *
 * @author Rozlina
 */
public class Greeting {
    
    public void greet(){
        System.out.println("Thank you for calling me!");
    }
}
