
package lesson1;

/**
 *
 * @author Rozlina
 */
public class Lesson1 {

   
    public static void main(String[] args) {
        System.out.println("Assalamualaikum. This is our first lesson!");
        
        //Greeting salam = new Greeting();
        //salam.greet();
    }
}
