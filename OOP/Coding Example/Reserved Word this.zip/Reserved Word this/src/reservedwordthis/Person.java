/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package reservedwordthis;

/**
 *
 * @author Owner
 */
public class Person {

    private int age;
    private String name;
    private double money;

public Person( ) {
    this(15);
    }

public Person(int umur) {
    this(umur,"No name",0.0);
                        }

public Person(int umur, String nama, double duit) {
    age=umur;
    name=nama;
    money =duit;                        }

public void display(){
    System.out.println("\nAge: " +age);
    System.out.println("Name: " +name);
    System.out.println("Money: RM" +money +"\n");}
       
}
