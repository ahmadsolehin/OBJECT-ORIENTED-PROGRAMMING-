/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson2;

/**
 *
 * @author Rozlina
 */
public class Lesson2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student std = new Student();
        System.out.println("Students' weight is " + std.getWeight());
        
        std.setWeight(45.5F);
        
        System.out.println("Students' weight is " + std.getWeight());
    }
}
