/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson2;

/**
 *
 * @author Rozlina
 */
public class Student {
    
    //data members
    private int age = 22;
    private String name = "Low";
    private float weight = 10.10F;
    
    //methods
    public float getWeight(){
        return weight;
    }
    
    public void setWeight(float newWeight){
        //if(newWeight > 0){ //validation
            weight = newWeight;
        //}
    }
}
