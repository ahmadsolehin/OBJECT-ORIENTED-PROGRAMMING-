/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passarrayobject;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Lecturer lecturer;
    lecturer = new Lecturer("Syahrir");

    Account[] accounts;//Declare the array variable
    accounts = new Account[4];//Create the array with size 4

    // Create several accounts using array
    accounts[0] = new Account(10000);
    accounts[1] = new Account(15000);
    accounts[2] = new Account(50000);
    accounts[3] = new Account(100000);

      
    lecturer.addAccount(accounts);

    System.out.println("\nThe Owner for these accounts is: "+ lecturer.getName());

    /*for(int i =0;i<4;i++)
    {
        System.out.println("Balance for Account["+ i +"] is: "
                +lecturer.getAccount(i).getBalance() );
    }*/
    System.out.println();

    //Return Array object
    Account[] accounts2;
    accounts2= lecturer.getAccount();

    for(int i =0;i<4;i++)
    {
        System.out.println("Balance for Account["+ i +"] is: "
                +accounts2[i].getBalance() );
    }  
    System.out.println();
    
    
    }
}
