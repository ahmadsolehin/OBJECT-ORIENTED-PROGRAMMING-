/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passarrayobject;

/**
 *
 * @author Owner
 */
public class Lecturer {

  private String  name;
   
  private Account[] accountsLect;

  public Lecturer(String name) {
    this.name=name;
  }

  public String getName() {
    return name;
  }

  public void addAccount(Account[] acct) {
    accountsLect = acct;
  }
  
  public Account getAccount(int account_index) {
    return accountsLect[account_index];

  }

  //Return array object
 public Account[] getAccount() {
       return accountsLect;}
  


}
