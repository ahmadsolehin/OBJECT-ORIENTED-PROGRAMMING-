/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passarrayobject;

/**
 *
 * @author Owner
 */
public class Account {

    private double balance;

    public Account(double bal)
    {
    balance = bal;
    }

    public double getBalance()
    {
    return balance;
    }


}
