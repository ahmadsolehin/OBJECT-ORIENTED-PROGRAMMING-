/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fskkp;

/**
 *
 * Vincent Tan
 */
public class Student {
    
    private String stdName;
    private String metric;
    private int year;
    private String course;
    private double cpa;
    private double gpa;
    int i=0;
    Subject subjek[];
        
    public Student(String name, String metric, int year, String course){
    
        stdName = name;
        this.metric = metric;
        this.year = year;
        this.course = course;
        
      
        
    }
    
    public String getStdName(){
        
        return stdName;
    }
    
    public String getMetric(){
        
        return metric;
    }
    
    public int getYear(){
        
        return year;
    }
    
    public String getCourse(){
    
            return course;
    }
    
    public double gpaCalculation(Subject ob[]){
        String gred;
        double [] gredP = new double[10];
        int i;
        for(i=0; i<5; i++){
        gred = ob[i].getGred();
        
        if("A".equals(gred)){
            
            gredP[i] = 4.0;
           
        }
        else if ("A-".equals(gred)){
            
            gredP[i] = 3.67;
        }
        else if ("B+".equals(gred)){
            
            gredP[i] = 3.33;
        }
        else if ("B".equals(gred)){
            
            gredP[i] = 3.0;
        }
        else if ("B-".equals(gred)){
            
            gredP[i] = 2.67;
        }
        else if ("C+".equals(gred)){
            
            gredP[i] = 2.33;
        }
        else if ("C".equals(gred)){
            
            gredP[i] = 2.0;
        }
        else if ("C-".equals(gred)){
            
            gredP[i] = 1.67;
        }
        else if ("D+".equals(gred)){
            
            gredP[i] = 1.33;
        }
        else if ("D".equals(gred)){
            
            gredP[i] = 1.0;
        }
        else if ("E".equals(gred)){
            
            gredP[i] = 0.67;
        }
        else{
            gredP[i] = 0.00;
        }
        }
        double totalgred=0;
        double[] weightedGred= new double [10];
        
        int totalcredit=0;
        for(i=0; i<5; i++){
        weightedGred[i]= gredP[i]*ob[i].getCredit();
        totalgred = totalgred+weightedGred[i];
        totalcredit = totalcredit +ob[i].getCredit();
        }
        gpa=totalgred/totalcredit;
        //System.out.println("GPA:"+ (gpa));
        
        
        return gpa;
    }
    
    public double cpaCalculation(Subject ob[], Subject ob1[]){
        double totalgredpoint =0;
        double totalcredit=0;
        double [] gredpoint1 = new double[10];
        double [] gredpoint2 = new double [10];
        int i=0;
        for (i=0; i<5; i++){
        gredpoint1[i]= (ob[i].getPoint()*ob[i].getCredit());
        gredpoint2[i]= (ob1[i].getPoint()*ob1[i].getCredit());
        totalgredpoint = totalgredpoint + gredpoint1[i] +gredpoint2[i];
        totalcredit = totalcredit +ob[i].getCredit()+ob1[i].getCredit();
        
        }
        cpa = totalgredpoint/totalcredit;
        
    
    
        return cpa;
    }
}
