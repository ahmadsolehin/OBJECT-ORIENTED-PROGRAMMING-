/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fskkp;

/**
 *
 * @author Vincent Tan
 */
public class ProgramTester {
   
    
    
     public static void main(String[] args) {
       
          
           Subject ob1[];
           Subject ob3[]= new Subject[10];
           Subject ob5[] = new Subject[10];
           
           Subject sub1[] =new Subject [10];
           Subject sub2[] =new Subject [10];
           Subject sub3[] =new Subject [10];
           
           Student ob2[]=new Student [10];
           Student ob4[]=new Student [10];
           Student ob6[]=new Student [10];
           
           int counter1 = 0;
          
           
           ob1 = new Subject[10];
                             
          ob1[0] = new Subject("OOP","BCS2012",3,"A");
          ob1[1] = new Subject("SAD","BCS2043",3,"E");
          ob1[2] = new Subject("Technical Writing","BCS2333",2,"D");
          ob1[3] = new Subject("Technical English","BCS2433",2,"B-");
          ob1[4] = new Subject("Data Structures","BCS2433",2,"B-");
          //semester 2
          sub1[0] = new Subject("Programming C","BCS2012",3,"B");
          sub1[1] = new Subject("Data Comm","BCS2043",3,"E");
          sub1[2] = new Subject("TE","BCS2333",2,"D");
          sub1[3] = new Subject("TW","BCS2433",2,"B-");
          sub1[4] = new Subject("Discrete Structure","BCS2433",2,"B-");
          
          ob2[0] = new Student("Wong Di Ing","CA11114", 2, "BCN");
          //--------------------------------------------------------------------
          ob3[0] = new Subject("OOP","BCS2012",3,"B");
          ob3[1] = new Subject("SAD","BCS2043",3,"C");
          ob3[2] = new Subject("Technical Writing","BCS2333",2,"B");
          ob3[3] = new Subject("Technical English","BCS2433",2,"B-");
          ob3[4] = new Subject("Data Structures","BCS2433",2,"B");
          //semester 2
          sub2[0] = new Subject("Programming C","BCS2012",3,"A");
          sub2[1] = new Subject("Data Comm","BCS2043",3,"B");
          sub2[2] = new Subject("TE","BCS2333",2,"C");
          sub2[3] = new Subject("TW","BCS2433",2,"B-");
          sub2[4] = new Subject("Discrete Structure","BCS2433",2,"B-");
          
          ob4[0] = new Student("Vincent Tan","CD11080", 2, "BCG");
          //--------------------------------------------------------------------
          ob5[0] = new Subject("OOP","BCS2012",3,"A");
          ob5[1] = new Subject("SAD","BCS2043",3,"B");
          ob5[2] = new Subject("Technical Writing","BCS2333",2,"C");
          ob5[3] = new Subject("Technical English","BCS2433",2,"D");
          ob5[4] = new Subject("Data Structures","BCS2433",2,"B-");
          //semester 2
          sub3[0] = new Subject("Programming C","BCS2012",3,"C");
          sub3[1] = new Subject("Data Comm","BCS2043",3,"C");
          sub3[2] = new Subject("TE","BCS2333",2,"D");
          sub3[3] = new Subject("TW","BCS2433",2,"B-");
          sub3[4] = new Subject("Discrete Structure","BCS2433",2,"B");
          
          ob6[0] = new Student("Ji Siang","CB10014", 2, "BCS");
          
          //student 1 ----------------------------------------------------------
          System.out.println("Name: " + ob2[0].getStdName()+ "  " + "No.Metric: " + ob2[0].getMetric()+ "  "+ "Year: "+ ob2[0].getYear()+ "  " + "Course: "  + ob2[0].getCourse());
          System.out.println("Subject:"+"                 Credit");
          
              System.out.println("Semester 1");
              for (counter1 = 0; counter1 <4; counter1++){
                  System.out.println("       " + ob1[counter1].getSubName()+"          " + ob1[counter1].getCredit());
              }
              System.out.println("GPA:" + ob2[0].gpaCalculation(ob1)); 
              
              System.out.println("Semester 2");
              for(counter1=0; counter1<4; counter1++){
                  System.out.println("       " + sub1[counter1].getSubName()+"          " + sub1[counter1].getCredit());
                  
                  
              }
              System.out.println("GPA:" + ob2[0].gpaCalculation(sub1)); 
              System.out.println("CPA:" + ob2[0].cpaCalculation(ob1, sub1)); 
    
              
              //student 2 ------------------------------------------------------
              System.out.println("Name: " + ob4[0].getStdName()+ "  " + "No.Metric: " + ob4[0].getMetric()+ "  "+ "Year: "+ ob4[0].getYear()+ "  " + "Course: "  + ob4[0].getCourse());
              System.out.println("Subject:"+"                 Credit");
          
              System.out.println("Semester 1");
              for (counter1 = 0; counter1 <4; counter1++){
              System.out.println("       " + ob3[counter1].getSubName()+"          " + ob3[counter1].getCredit());
              }
              System.out.println("GPA:" + ob4[0].gpaCalculation(ob3)); 
              
              System.out.println("Semester 2");
              for(counter1=0; counter1<4; counter1++){
              System.out.println("       " + sub2[counter1].getSubName()+"          " + sub2[counter1].getCredit());
                  
                  
              }
              System.out.println("GPA:" + ob4[0].gpaCalculation(sub2)); 
              System.out.println("CPA:" + ob4[0].cpaCalculation(ob3, sub2)); 
     
              //student 3 ------------------------------------------------------
                          
              System.out.println("Name: " + ob6[0].getStdName()+ "  " + "No.Metric: " + ob6[0].getMetric()+ "  "+ "Year: "+ ob6[0].getYear()+ "  " + "Course: "  + ob6[0].getCourse());
              System.out.println("Subject:"+"                 Credit");
          
              System.out.println("Semester 1");
              for (counter1 = 0; counter1 <4; counter1++){
                  System.out.println("       " + ob5[counter1].getSubName()+"          " + ob5[counter1].getCredit());
              }
              System.out.println("GPA:" + ob6[0].gpaCalculation(ob1)); 
              
              System.out.println("Semester 2");
              for(counter1=0; counter1<4; counter1++){
                  System.out.println("       " + sub3[counter1].getSubName()+"          " + sub3[counter1].getCredit());
                  
                  
              }
              System.out.println("GPA:" + ob6[0].gpaCalculation(sub3)); 
              System.out.println("CPA:" + ob6[0].cpaCalculation(ob5, sub3)); 
                               
     }
          
     
    }
     
    

