/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fskkp;

/**
 *
 * Vincent Tan
 */
public class Subject {
    
    private String[] SubName = new String[10];
    private String[] code = new String[10];
    private int[] credit = new int[10];
    private String[] gred = new String[10];
    private double[] point = new double[10];
    private double[] cpa = new double[10];
    private double[] gpa= new double[10];
    Student st;
    int counter;
    
    public Subject(String sub, String code, int credit, String gred){
        
        SubName[counter]= sub;
        this.code[counter] = code;
        this.credit[counter] = credit;
        this.gred[counter] = gred;
       
        
    }
    
    public String getSubName(){
        
        return SubName[counter];
    }
    
    public String getCode(){
    
        return code[counter];
    }
    
    public int getCredit(){
    
        return credit[counter];
    }
    
    public String getGred(){
       
    
        return gred[counter];
    }
    
    public double getPoint(){
        if("A".equals(gred[counter])){
        point[counter]=4.0;
        }
        else if ("A-".equals(gred[counter])){
            
            point[counter] = 3.67;
        }
        else if ("B+".equals(gred[counter])){
            
            point[counter] = 3.33;
        }
        else if ("B".equals(gred[counter])){
            
            point[counter] = 3.0;
        }
        else if ("B-".equals(gred[counter])){
            
            point[counter] = 2.67;
        }
        else if ("C+".equals(gred[counter])){
            
            point[counter] = 2.33;
        }
        else if ("C".equals(gred[counter])){
            
            point[counter] = 2.0;
        }
        else if ("C-".equals(gred[counter])){
            
            point[counter] = 1.67;
        }
        else if ("D+".equals(gred[counter])){
            
            point[counter] = 1.33;
        }
        else if ("D".equals(gred[counter])){
            
            point[counter] = 1.0;
        }
        else if ("E".equals(gred[counter])){
            
            point[counter] = 0.67;
        }
        else{
            point[counter] = 0.00;
        }
        
            
        
    
        return point[counter];
    }
    
    public double getCpa(){
        
         
        
        return cpa[counter];
    }
    
    public double getGpa(){
        gpa[counter]= point[counter]*credit[counter];
         
        
        return gpa[counter];
    }
    
    
    

}
