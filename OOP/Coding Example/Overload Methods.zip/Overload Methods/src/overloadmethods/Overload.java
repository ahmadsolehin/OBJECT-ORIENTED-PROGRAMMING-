/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package overloadmethods;

/**
 *
 * @author Owner
 */
public class Overload {

public void myMethod(int x)
{
System.out.println("\nI'm at myMethod(int x)");
System.out.println("Value for x is:" +x);
}

public double myMethod(double x)
{
System.out.println("\nI'm at myMethod(double x)");
System.out.println("Value for x is:" +x);
return 0.0;
}

public void myMethod(int x, int y)
{
System.out.println("\nI'm at myMethod(int x, int y)");
System.out.println("Value for x is:" +x);
System.out.println("Value for y is:" +y);

}





}
