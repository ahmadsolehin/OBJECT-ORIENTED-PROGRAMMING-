/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package overloadmethods;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Overload obj1;

        obj1 = new Overload();

        obj1.myMethod(10.5);
       

    }

}
