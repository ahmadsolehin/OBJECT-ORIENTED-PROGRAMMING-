
package model;


public class Customer {
    private String name;
    private String address;
    private String telephone;
    private String position;

    public Customer(String name, String address, String telephone, String position) {
        this.name = name;
        this.address = address;
        this.telephone = telephone;
        this.position = position;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }



}
