package model;

import java.io.*;
import javax.swing.JOptionPane;
import java.util.*;
public class CustomerList {
    private LinkedList <Customer> list = new LinkedList <Customer> ();

    public CustomerList() {
        try {
            FileReader fr = new FileReader("customer");
            BufferedReader br = new BufferedReader(fr);

            String stmt = br.readLine();
            while (stmt != null) {
                int num1 = stmt.indexOf(", ");
		String name = stmt.substring(0, num1);

                int num2 = stmt.indexOf(", ", num1+1);
		String address = stmt.substring(num1+2, num2);

		int num3 = stmt.indexOf(", ", num2+1);
		String telephone = stmt.substring(num2+2, num3);

		String position = stmt.substring(num3+2);

                Customer cust = new Customer(name, address, telephone, position);
                list.add(cust);
                stmt = br.readLine();
            }
          } catch (Exception e){
                JOptionPane.showMessageDialog(null, "error in reading data from file");
            }
        }

       public LinkedList getCustomerList() {
           return list;
       }
    }


