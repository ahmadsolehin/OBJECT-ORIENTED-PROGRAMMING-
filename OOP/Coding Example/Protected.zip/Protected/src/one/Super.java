/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package one;

/**
 *
 * @author Owner
 */
public class Super {

    public int age;

    public Super(){
        age=20;
    }
    
     public void displaySuper()
        {
           System.out.println("\nAge for mySuper using displaySuper() is:"+this.age);
        }

}
