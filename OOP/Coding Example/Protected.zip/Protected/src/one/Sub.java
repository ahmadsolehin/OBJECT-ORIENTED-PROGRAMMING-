/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package one;

/**
 *
 * @author Owner
 */
public class Sub extends Super {

    public Sub()
    {
       age=10;
    }
    
    Super mySuper2 = new Super();

    public void displaySub()
        {
        System.out.println("\nAge for mySuper2 using displaySub() is:"+mySuper2.age);
        System.out.println("\nAgefor mySub using displaySub() is:"+this.age);

        }

}
