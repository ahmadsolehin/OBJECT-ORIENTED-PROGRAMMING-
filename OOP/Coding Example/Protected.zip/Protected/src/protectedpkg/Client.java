/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protectedpkg;

/**
 *
 * @author Owner
 */

import one.*;
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Super mySuper = new Super( );
	Sub   mySub   = new Sub( );

        int i = mySuper.age;
        System.out.println("\nAge for mySuper using main() method is:"+i);

        mySuper.displaySuper();
        mySub.displaySub();

        System.out.println();
       
    }

}
