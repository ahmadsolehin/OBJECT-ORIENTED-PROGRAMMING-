/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gemilangcorporation2;

/**
 *
 * @author ump
 */
import java.util.*;
import java.text.*;
public class RentalApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      DecimalFormat df = new DecimalFormat("0.00");

      Scanner scanner;

      Customer cust;
      Rental rent;
      VCD[] vcd;

      vcd=new VCD[3];


      String custName,custAdd,ctxNo;
      int rentDay;
      double sumPrice=0, discPrice=0, totalPrice=0;

      cust = new Customer();

      scanner = new Scanner(System.in);

      System.out.println("Please enter Customer Name:");
      custName = scanner.nextLine();
      cust.setName(custName);

      System.out.println("Please enter Customer Address:");
      custAdd = scanner.nextLine();
      cust.setAddress(custAdd);

      System.out.println("Please enter Customer Contact No :");
      ctxNo = scanner.nextLine();
      cust.setContactNo(ctxNo);

      System.out.println("\nPlease enter Rental Days:");
      String day = scanner.nextLine();
      rentDay = Integer.parseInt(day);

      rent = new Rental(cust,rentDay);


      for (int i=0;i<3;i++){
      System.out.println("\nPlease enter VCD title: ");
      String title = scanner.nextLine();

      System.out.println("Please enter VCD genre:");
      String genre = scanner.nextLine();

      System.out.println("Please enter VCD rental price: ");
      String price = scanner.nextLine();
      double rentprice = Double.parseDouble(price);

      vcd[i]= new VCD(title,rentprice,genre);

      }


      

      for (int i=0;i<3;i++){
       sumPrice=  sumPrice + rent.calculateRentalPrice(vcd[i]);
      }

      
      discPrice= rent.calculateDisc(sumPrice );
      totalPrice =  sumPrice - discPrice;

      rent.displayCustomerInfo();

      for (int j=0;j<3;j++){
      int vcdNumber=j+1;
      System.out.println("\n"+"VCD " + vcdNumber+":");
      rent.displayVCDInfo(vcd[j]);
      }

      System.out.println("\nDiscount: RM" +df.format(discPrice));
      System.out.println("Total Price: RM" +df.format(totalPrice));



    }

}
