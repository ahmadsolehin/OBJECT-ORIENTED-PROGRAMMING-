package gemilangcorporation2;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FSKKP
 */
public class VCD {
private String title;
private double rentPrice;
private String genre;

public VCD(String t,double r,String g){
    title =t;
    rentPrice = r;
    genre = g;
}

public String getTitle(){
    return title;
}
public double getRentPrice(){
    return rentPrice;
}
public String getGenre(){
    return genre;
}
}
