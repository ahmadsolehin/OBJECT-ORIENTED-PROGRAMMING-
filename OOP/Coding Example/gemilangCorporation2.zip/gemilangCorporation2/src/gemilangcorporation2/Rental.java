package gemilangcorporation2;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FSKKP
 */
import java.text.*;
public class Rental {
//private VCD vcd;
private Customer cust;
private double rentalPrice;
private int rentDay;

public Rental(Customer c, int d){
    //vcd =v;
    cust=c;
    rentDay = d;
}

public Rental(int day)
{
   rentDay=day;
}


public double calculateRentalPrice(VCD v){
    rentalPrice = v.getRentPrice()*rentDay;
    return rentalPrice;
}
public int getRentDays(){
    return rentDay;
}

public double calculateDisc(double t){
    double discPrice=0;
      
        
    if (t>1 & t<6)
    {
        discPrice=t*0.01;
    }
    
    else if (t>=6 & t<11)
    {
        discPrice=t*0.02;
    }
    
    else 
    {
        discPrice=t*0.05;
    }

    return discPrice;
}


public void displayCustomerInfo(){
    
      System.out.println("\nCustomer Name: " + cust.getName());
      System.out.println("Customer Address: " + cust.getAddress());
      System.out.println("Customer Contact No: " + cust.getContactNo());
      System.out.println("Rent Days: " + getRentDays());
}
public void displayVCDInfo(VCD v){

      DecimalFormat df = new DecimalFormat("0.00");

      System.out.println("     "+"Title: " + v.getTitle());
      System.out.println("     "+"Genre: " + v.getGenre());
      System.out.println("     "+"Rental Price: RM " + df.format(v.getRentPrice())+"/day");

     }

}

