package gemilangcorporation2;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FSKKP
 */
public class Customer {
private String name;
private String address;
private String contactNo;

public String getName(){
    return name;
}

public String getAddress(){
    return address;
}
public String getContactNo(){
    return contactNo;
}
public void setName(String n){
    name =n;
}
public void setAddress(String a){
    address = a;
}
public void setContactNo(String c){
    contactNo = c;
}
}
