/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractpkg;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Cat cat1 = new Cat("Comel");
        cat1.eat();//eat() for cat1 is different from eat() for spider1
        cat1.walk();

        Spider spider1 = new Spider();
        spider1.eat();//eat() here is polymorphism because
                //same name but different implementation.
        spider1.walk();


        Animal[] animals;
        animals  = new Animal[10];

        /*Polymorphism also allows a variable from superclass to refer to....
            objects from different subclasses.*/
        animals[0]= new Cat("Puss");
        animals[1]= new Spider();
        animals[2]= new Cat("Garfield");

        animals[0].eat();
        animals[1].eat();
        animals[2].eat();



       
       
    }

}
