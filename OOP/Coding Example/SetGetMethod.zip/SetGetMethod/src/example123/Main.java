/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package example123;

/**
 *
 * @author ump
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Declare the object. Give the name for the object
        Bicycle bike1;

        //Create the object
        bike1 = new Bicycle();
       

       bike1.setOwnerName("Syahrir");

       System.out.println("The owner for this bicycle is: "+bike1.getOwnerName());
       bike1.display();

       

    }

}
