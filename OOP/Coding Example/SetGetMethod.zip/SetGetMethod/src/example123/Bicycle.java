/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package example123;

/**
 *
 * @author ump
 */
public class Bicycle {
    
    private String ownerName;


    public void setOwnerName(String name)
    {
        ownerName=name;
    }

    public String getOwnerName()
    {
        return ownerName;
    }


    public void display()
    {
       System.out.println("I have a bicycle. Can I be your friend?");
    }

}
