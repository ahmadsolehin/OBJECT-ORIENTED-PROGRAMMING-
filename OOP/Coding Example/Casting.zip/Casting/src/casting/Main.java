/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package casting;

/**
 *
 * @author ump
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double ans=5/2;// loss precision

        System.out.println(ans);

        // to do a correct calculation... either one must be double

        double ans2 = 5.0/2;
        System.out.println(ans2);

        // or... this mean we convert 5 first to become double
        double ans3 = (double)5/2;
        System.out.println(ans3);

        //this one is wrong because the calculation is already done as integer
        double ans4= (double)(5/2);
        System.out.println(ans4);

         //both is double is correct.
        double ans5= (double)5/(double)2;
        System.out.println(ans5);
    }

}
