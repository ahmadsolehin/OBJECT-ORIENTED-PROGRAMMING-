/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package superpkg;

/**
 *
 * @author Owner
 */
public class Cat extends Animal{
    private String name;

    public Cat(String name)
    {
     super(4);
    this.name = name;

    }

    public void eat()
    {
    System.out.println("\nCats eat fish.");
    }


}
