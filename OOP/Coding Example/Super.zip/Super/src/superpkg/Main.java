/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package superpkg;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Cat cat1 = new Cat("Comel");
        cat1.eat();//eat() for cat1 is different from eat() for spider1
        cat1.walk();

        Spider spider1 = new Spider();
        spider1.eat();//eat() here is polymorphism because
                //same name but different implementation.

        spider1.walk();
    }

}
