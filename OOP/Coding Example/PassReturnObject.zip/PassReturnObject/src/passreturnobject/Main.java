/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passreturnobject;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // TODO code application logic here
        PTPTN_Account account1;// declare an object from class PTPTN_Account
        Student stud1;//declare an object from class Student

        
        account1 = new PTPTN_Account(5000);//create the account1 object
        System.out.println("\nThe object address for account1 is:"+account1);

        stud1 =new Student("Syafiq");//create the stud1 object

        //account1 =19821F
        stud1.setAccount(account1);

        System.out.println("\nStudent Name: " +stud1.getName());

        System.out.println("Balance: RM" + stud1.getAccount().getBalance()+"\n");

       

    }

}
