/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passreturnobject;

/**
 *
 * @author Owner
 */
public class Student {
     
    private String name;

    private PTPTN_Account account;//declare an object inside a class

    public Student(String name)
    {    this.name= name;
    }

    public String getName(){
        return name;
    }

    public void setAccount( PTPTN_Account acct ){//pass an object to a method
        account =acct;
        System.out.println("\nContent for acct is:"+acct);
        System.out.println("\nContent for accountt is:"+account);
    }
    
     public PTPTN_Account getAccount(){//return an object from a method
        return account;
    }

}
