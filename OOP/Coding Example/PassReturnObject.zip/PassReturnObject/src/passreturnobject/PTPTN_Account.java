/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package passreturnobject;

/**
 *
 * @author Owner
 */
public class PTPTN_Account {

    private double balance;

    public PTPTN_Account(double bal){
        balance=bal;
    }

    public double getBalance(){
        return balance;
    }

    

}
