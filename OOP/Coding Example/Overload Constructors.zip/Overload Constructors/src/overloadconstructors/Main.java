/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package overloadconstructors;

/**
 *
 * @author Owner
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Person person1,person2,person3;

        person1= new Person();
        person2= new Person(20,"Syahrir",150000);
        person3= new Person(15);

        person2.display();


        
    }

}
