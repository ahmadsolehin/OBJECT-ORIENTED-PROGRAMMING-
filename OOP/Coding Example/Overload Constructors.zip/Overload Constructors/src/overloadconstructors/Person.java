/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package overloadconstructors;

/**
 *
 * @author Owner
 */
public class Person {

    private int age;
    private String name;
    private double money;

public Person( ) {
    age=0;
    name="No name";
    money = 0.0; }

public Person(int umur) {
    age=umur;
    name="No name";
    money = 0.0;         }

public Person(int age, String name, double money) {
    this.age=age;
    this.name=name;
    this.money =money;                        }

public void display(){
    System.out.println("\nAge: " +age);
    System.out.println("Name: " +name);
    System.out.println("Money: RM" +money +"\n");}      
}
