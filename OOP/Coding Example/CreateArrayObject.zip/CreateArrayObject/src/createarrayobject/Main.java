/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package createarrayobject;

/**
 *
 * @author ump
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //An Array is like an object
        //Declare & Create an array. Noticed the [] is not () for array
        Account[] accounts;//Declare accounts as an array object
        accounts = new Account[4];//Create the array with size 4

        // Create several accounts object and
        accounts[0] = new Account(10000);
        accounts[1] = new Account(15000);
        accounts[2] = new Account(50000);
        accounts[3] = new Account(100000);


        for(int iCounter =0;iCounter<4;iCounter++)
    {
        System.out.println("Balance for Account["+ iCounter +"] is: "
                +accounts[iCounter].getBalance() );
    }
    }

}
