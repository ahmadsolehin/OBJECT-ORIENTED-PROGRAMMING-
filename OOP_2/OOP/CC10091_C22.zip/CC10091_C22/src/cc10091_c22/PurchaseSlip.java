/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc10091_c22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class PurchaseSlip {
    
    private double subtotal;
    private double tax;
    private double discount;
    private double total;
    private double price;
    private int quantity;
    private double allPriceItem;
    Scanner a = new Scanner(System.in);

    public PurchaseSlip(double subtotal, double tax, double discount, double total) {
        this.subtotal = subtotal;
        this.tax = tax;
        this.discount = discount;
        this.total = total;
    }
    
    public void calcSubtotal (double subtotal){
        
        subtotal = (price * quantity) + allPriceItem;
        
    }
    
    public void calcTax (double tax){
        
        tax = 0.05 * subtotal;
    }
    
    public void calcDiscount (double discount){
        
        discount = 0.03 * subtotal;     
    }
    
    public void calctotal (double total){
        
        total = (subtotal + tax) - discount;
        
    }

    public double getDiscount() {
        return discount;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getTax() {
        return tax;
    }

    public double getTotal() {
        return total;
    }
    
    
}
