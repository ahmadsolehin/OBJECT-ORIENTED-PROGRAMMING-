/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc10091_c22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Customer {
    private String memberName;
    private String memberAddress;
    private String memnbershipNo;
    Scanner a = new Scanner(System.in);
    
    public Customer(String memberName, String memberAddress, String memnbershipNo) {
        this.memberName = memberName;
        this.memberAddress = memberAddress;
        this.memnbershipNo = memnbershipNo;
    }

    public String getMemberAddress() {
        return memberAddress;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMemnbershipNo() {
        return memnbershipNo;
    }
    
    public void customer(){
        System.out.println("Enter Name: ");
        memberName = a.next ();
        System.out.println("Enter Address: ");
        memberAddress = a.next();
        System.out.println("Enter Membership No : ");
        memnbershipNo = a.next();
    }
}
