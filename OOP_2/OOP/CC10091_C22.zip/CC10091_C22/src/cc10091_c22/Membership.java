/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc10091_c22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Membership {
    private double memberPoint;
    private double OldMemberPoint;
    private double redeemPoint;
    private double newPoint;
    private String membershipType;
    private double redeemItem;
    private double total;
    Scanner a = new Scanner(System.in);
     
    public Membership(double memberPoint, double OldMemberPoint, double redeemPoint, double newPoint, String membershipType) {
        this.memberPoint = memberPoint;
        this.OldMemberPoint = OldMemberPoint;
        this.redeemPoint = redeemPoint;
        this.newPoint = newPoint;
        this.membershipType = membershipType;
    }
    
    public void calcRedeemPoint (double redeemPoint){
        redeemPoint = redeemItem;   
    }
    
    public void calcNewPoint (double newPoint){
        newPoint = 0.10 * total;
        }
    
    public void calcMemberPoint (double memberPoint){
       memberPoint = ( + newPoint );
    }
    
    public void calcOldMemberPoint (double OldMemberPoint){
       OldMemberPoint = (+ newPoint);
       
    }
    public void determineMembershipType (){
      
        if( OldMemberPoint >= 10000.00) {
           
            membershipType = "GOLD";
        
            }else
            
            if( OldMemberPoint < 10000.00){
                
             membershipType = "SILVER";   
            }
}

    public double getOldMemberPoint() {
        return OldMemberPoint;
    }

    public double getMemberPoint() {
        return memberPoint;
    }

    public String getMembershipType() {
        return membershipType;
    }

    public double getNewPoint() {
        return newPoint;
    }

    public double getRedeemItem() {
        return redeemItem;
    }

    public double getRedeemPoint() {
        return redeemPoint;
    }

    public double getTotal() {
        return total;
    }
    
     public void membership(){
        System.out.println("Enter Member Point: ");
        memberPoint = a.nextDouble();
        System.out.println("Enter Old Member Point: ");
        OldMemberPoint = a.nextDouble();
        System.out.println("Enter MemberShip Type: ");
        membershipType = a.next();
     }
}