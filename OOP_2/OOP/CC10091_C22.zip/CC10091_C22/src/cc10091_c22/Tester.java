/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc10091_c22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String memberName, memberAdd, membershipNo;
        double memberPoint, oldMemberPoint, redeemPoint, newPoint, membershipType;
     int i,j;
     
     Customer cust = new Customer("","","");
     PurchaseOrder po = new PurchaseOrder("",1,0,0);
     Scanner sc =new Scanner(System.in);
     
     System.out.println("Name :");
     memberName=sc.next();
     System.out.println("Address :");
     memberAdd=sc.next();
     System.out.println("Membership No. :");
     membershipNo=sc.next();
       
     System.out.println("Member Point :");
     memberPoint=sc.nextDouble();
     System.out.println("Old member Point :");
     oldMemberPoint=sc.nextDouble();
     System.out.println("New Point :");
     newPoint=sc.nextDouble();
     System.out.println("Membership Type :");
     membershipType=sc.nextDouble();
     
}
}
