/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cc10091_c22;

/**
 *
 * @author FSK4
 */
public class PurchaseOrder {
    
    private String item;
    private int quantity;
    private double price;
    private double amount;

    public PurchaseOrder(String item, int quantity, double price, double amount) {
        this.item = item;
        this.quantity = quantity;
        this.price = price;
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public String getItem() {
        return item;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }
    
    
    
}
