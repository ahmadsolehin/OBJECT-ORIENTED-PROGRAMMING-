/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CC10102_C22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Membership {
    private double memberPoint;
    private double oldMemberPoint;
    private double redeemPoint;
    private double newPoint;
    private String memberType;
    Scanner keyIn3 = new Scanner (System.in);
    private String silver;
    private String gold;

    public Membership(double memberPoint, double oldMemberPoint, double redeemPoint, double newPoint, String memberType) {
        this.memberPoint = memberPoint;
        this.oldMemberPoint = oldMemberPoint;
        this.redeemPoint = redeemPoint;
        this.newPoint = newPoint;
        this.memberType = memberType;
    }

    public double getMemberPoint() {
        return memberPoint;
    }

    public String getMemberType() {
        return memberType;
    }

    public double getNewpoint() {
        return newPoint;
    }

    public double getOldMemberPoint() {
        return oldMemberPoint;
    }

    public double getRedeemPoint() {
        return redeemPoint;
    }
    
    public void MembershipKeyIn3(){
        System.out.println(" Enter Customer Member Point :");
        memberPoint = keyIn3.nextDouble();
        System.out.println(" enter Customer Old Member Point :");
        oldMemberPoint = keyIn3.nextDouble();
        System.out.println(" Enter Customer New Point :");
        newPoint = keyIn3.nextDouble();
        System.out.println(" Enter Customer Membership Type :");
        
    }
    
    public void redeemPoint(String grade){
        if(redeemPoint < 1000);{
        
            silver = "Silver";
            
    }
        if(redeemPoint >= 1000);{
        
            gold = " Congratulation >> upgrade membership to GOLD ";
            
    }
        
        memberPoint = memberPoint + newPoint;
        oldMemberPoint = memberPoint + newPoint;
        
        
    
        
        
    }
        
    }
        
        
        
        

    
    

