/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CC10102_C22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Customer {
    private String memberName;
    private String memberAddress;
    private String membershipNo;
    Scanner keyIn = new Scanner(System.in);

    public Customer(String memberName, String memberAddress, String membershipNo) {
        this.memberName = memberName;
        this.memberAddress = memberAddress;
        this.membershipNo = membershipNo;
    }

    public String getMemberAddress() {
        return memberAddress;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMembershipNo() {
        return membershipNo;
    }
    
    public void customerKeyIn(){
        System.out.println(" Enter Customer Member Name :");
        memberName = keyIn.next();
        System.out.println(" Enter Customer Member Address :");
        memberAddress = keyIn.next();
        System.out.println(" Enter Customer Membership Number :");
        membershipNo = keyIn.next();
        
        
    }
    
    
    
}
