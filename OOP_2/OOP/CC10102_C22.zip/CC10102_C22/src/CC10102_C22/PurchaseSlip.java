/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CC10102_C22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class PurchaseSlip {
    private double subTotal;
    private double tax;
    private double discount;
    private double total;
    Scanner keyIn4 = new Scanner(System.in);
    private String purchaseSlip;

    public PurchaseSlip(double subTotal, double tax, double discount, double total) {
        this.subTotal = subTotal;
        this.tax = tax;
        this.discount = discount;
        this.total = total;
    }

    public double getDiscount() {
        return discount;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public double getTax() {
        return tax;
    }

    public double getTotal() {
        return total;
    }
    
    public void PurchaseSlipKeyIn4(){
        System.out.println(" Customer SubTotal :");
        subTotal = keyIn4.nextDouble();
        System.out.println(" Customer Tax :");
        tax = keyIn4.nextDouble();
        System.out.println(" Customer Discount :");
        discount = keyIn4.nextDouble();
        System.out.println(" Total Price :");
        total = keyIn4.nextDouble();
        System.out.println("\t");
        
    }
    
    public void subTotal (PurchaseOrder po[], int n){
        if (" item + quantity + price + amount ".equals(n)){
            subTotal = 187.80;
                    
        }else
       
      
             
             
        {
             
     
              discount = subTotal - discount;
              total = subTotal + tax - discount;
              
      }
       
     
          
         
     }
        
       public void display(Membership member, PurchaseOrder order, PurchaseSlip slip){
           System.out.println(" Enter Customer Member Point: " + member.getMemberPoint());
           System.out.println(" Enter Customer Member Old Point: " + member.getOldMemberPoint());
           System.out.println(" Enter Customer Redeem point:" + member.getRedeemPoint());
           System.out.println(" Enter Customer Membership type :" + member.getMemberType());
           
           System.out.println(" Enter Customer Item:" + order.getItem());
           System.out.println(" Enter Quantity :" + order.getQuantity());
           System.out.println(" Enter Price:" + order.getPrice());
           System.out.println(" Enter Customer Amount :" + order.getAmount());
           
           System.out.println(" Enter Customer SubTotal :" + slip.getSubTotal());
           System.out.println(" Enter Customer Tax :" + slip.getTax());
           System.out.println(" Enter Customer Discount :" + slip.getDiscount());
           System.out.println(" Enter Customer Total :" + slip.getTotal());
           
       }
       
       
           
       }
           
      
        
   
    
