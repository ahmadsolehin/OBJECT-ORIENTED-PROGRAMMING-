/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CC10102_C22;

import java.util.Scanner;

/**
 *
 * @author FSK4
 */
public class Tester {
    
    private String cust;
    private String member;
    private String po;
    private String ps;
    

    public static void main(String[] args) {
        
      Customer cust = new Customer ("", "", "");
      PurchaseOrder po = new PurchaseOrder ("", 1, 0, 0);
      Scanner input = new Scanner (System.in);
       
        
        
        
    }
}
